import sqlite3

# Connect to the SQLite database
conn = sqlite3.connect('vis.db')
cursor = conn.cursor()

# Create a table to store image information
cursor.execute('''CREATE TABLE IF NOT EXISTS Images
                  (id INTEGER PRIMARY KEY AUTOINCREMENT, filename TEXT, filepath TEXT)''')

# Function to insert image information into the database
def insert_images(images):
    for filename, filepath in images:
        cursor.execute("INSERT INTO Images (filename, filepath) VALUES (?, ?)", (filename, filepath))
    conn.commit()

# Function to retrieve image information from the database
def get_image(image_id):
    cursor.execute("SELECT filename, filepath FROM Images WHERE id=?", (image_id,))
    result = cursor.fetchone()
    if result:
        return result[0], result[1]
    else:
        return None

# Example usage
images = [("finance_smooting.PNG", "finance_smooting.PNG"), ("environment_k.PNG", "environment_k.PNG"), ("finance_k.PNG", "environment_k.PNG"), ("energy_k.PNG", "energy_k.PNG")
          , ("arima_a.PNG", "arima_a.PNG"), ("serima_a.PNG", "serima_a.PNG"), ("smooting_env.PNG", "smoothing_env.PNG")]
insert_images(images)

for image_id in range(1, len(images) + 1):
    filename, filepath = get_image(image_id)
    if filepath:
        print("Image ID:", image_id)
        print("Filename:", filename)
        print("Filepath:", filepath)
        print()
    else:
        print(f"Image with ID {image_id} not found.")
